namespace DigitalClockApp
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }
    }
}